from relatorio import Relatorio

template = Relatorio()
template.gerar_relatorio()